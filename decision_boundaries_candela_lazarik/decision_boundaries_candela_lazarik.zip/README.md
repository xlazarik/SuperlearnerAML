# Authors: David Candela, Vladimir Lazarik


## Project requires various packages such as H2o and altair
Installation via pip is available at the head of each jupyter notebook and needs to be uncommented if issues are encountered.

Code was run through jupyter lab as jupyter notebooks.

Python version 3.8


#############################################################################################
